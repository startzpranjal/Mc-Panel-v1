// ================================================
// Minecraft Server Panel - Consolidated App.js
// ================================================
// Dependencies
const express = require('express');
const session = require('express-session');
const sqlite3 = require('sqlite3').verbose();
const fs = require('fs');
const path = require('path');
const bcrypt = require('bcryptjs');
const { spawn, exec } = require('child_process');
const util = require('util');
const execAsync = util.promisify(exec);
const multer = require('multer');
const archiver = require('archiver');
const unzipper = require('unzipper');
const axios = require('axios');
const pidusage = require('pidusage');
const sanitize = require('sanitize-filename');
const zlib = require('zlib');
const prismarineNbt = require('prismarine-nbt');
const { promisify } = require('util');
const http = require('http');
const socketIo = require('socket.io');
const os = require('os');
const net = require('net'); // Added for IP validation
const flash = require('connect-flash');
const { Rcon } = require('rcon-client');
const ssh2 = require('ssh2'); // Added for SFTP Server support

// Promisify NBT parsing
const nbtParse = promisify(prismarineNbt.parse);
// Initialize Express app
const app = express();
const server = http.createServer(app);
const io = socketIo(server);
const router = express.Router();
app.use(flash());
app.use(session({
    secret: 'keyboard cat',
    resave: false,
    saveUninitialized: false
}));
app.use((req, res, next) => {
    res.locals.messages = req.flash(); // <-- THIS FIXES IT
    next();
});
// Configuration
const port = process.env.PORT || 3000;
const sftpPort = process.env.SFTP_PORT || 3002; // Configured SFTP port
const DATA_DIR = __dirname;
const DB_PATH = path.join(DATA_DIR, 'database.db');
const SERVERS_DIR = path.join(DATA_DIR, 'servers');
const SFTP_KEY_PATH = path.join(DATA_DIR, 'sftp_host_key');

// Ensure directories exist
if (!fs.existsSync(SERVERS_DIR)) {
    fs.mkdirSync(SERVERS_DIR, { recursive: true });
    console.log('Created servers directory:', SERVERS_DIR);
}

// Open Database Instance
const db = new sqlite3.Database(DB_PATH);

// Global state
global.serverProcesses = {};
const serverStartTimes = {};
const onlinePlayers = {};
const serverLogWatchers = {};

// ================================================
// SFTP SERVER MANAGEMENT SYSTEM
// ================================================

// Generate host key if it doesn't exist (Required by SSH2)
if (!fs.existsSync(SFTP_KEY_PATH)) {
    console.log('Generating SFTP host key, please wait...');
    try {
        // Creates a basic standalone host key for development purposes
        const crypto = require('crypto');
        const { privateKey } = crypto.generateKeyPairSync('rsa', {
            modulusLength: 2048,
            publicKeyEncoding: { type: 'pkcs1', format: 'pem' },
            privateKeyEncoding: { type: 'pkcs1', format: 'pem' }
        });
        fs.writeFileSync(SFTP_KEY_PATH, privateKey);
    } catch (err) {
        console.error('Failed to auto-generate SFTP key:', err.message);
    }
}

// Start SFTP subsystem daemon
const sftpServer = new ssh2.Server({
    hostKeys: [fs.readFileSync(SFTP_KEY_PATH)]
}, (client) => {
    let authenticatedUser = null;

    client.on('authentication', (ctx) => {
        // Authenticate only with password method
        if (ctx.method !== 'password') return ctx.reject(['password']);

        // Check user credentials inside your SQLite database
        // Expected database table schema: users (username, password)
        db.get('SELECT password FROM users WHERE username = ?', [ctx.username], (err, row) => {
            if (err || !row) {
                return ctx.reject();
            }
            // Verify BCrypt password match
            bcrypt.compare(ctx.password, row.password, (bcryptErr, match) => {
                if (match && !bcryptErr) {
                    authenticatedUser = ctx.username;
                    return ctx.accept();
                }
                return ctx.reject();
            });
        });
    }).on('ready', () => {
        client.on('session', (accept) => {
            const session = accept();
            session.on('sftp', (acceptSftp, rejectSftp) => {
                const sftpStream = acceptSftp();
                // Instantiate the node-fs abstraction layer bound to the server pathing system
                // Users are locked into the global data root directory via this instance
                const sftpFS = new ssh2.SFTPStream.LocalFS(SERVERS_DIR);
                
                // Mount internal handlers to direct system calls
                sftpStream.on('OPEN', (id, filename, flags, attrs) => {
                    const safePath = path.join(SERVERS_DIR, sanitize(filename));
                    sftpFS.open(safePath, flags, attrs, (err, handle) => {
                        if (err) return sftpStream.status(id, ssh2.SFTP_STATUS.FAILURE);
                        sftpStream.handle(id, handle);
                    });
                });
                
                // Pipeline fallback pipe mechanisms onto local FS handles
                ssh2.SFTPStream.attach(sftpStream, sftpFS);
            });
        });
    }).on('close', () => {
        // Clean up connections gracefully
    });
});

sftpServer.listen(sftpPort, '0.0.0.0', () => {
    console.log(`SFTP Daemon actively listening on port: ${sftpPort}`);
});

// ================================================
// SERVER SOFTWARE MANAGEMENT SYSTEM
// ================================================

// Comprehensive server software definitions
const SERVER_SOFTWARE = {
    // Java Edition Servers
    vanilla: {
        name: 'Vanilla',
        description: 'Official Minecraft server software from Mojang',
        category: 'Java Edition',
        icon: 'fas fa-cube',
        color: '#8B4513',
        downloadUrl: 'https://launcher.mojang.com/v1/objects/{hash}/server.jar',
        manifestUrl: 'https://launchermeta.mojang.com/mc/game/version_manifest.json',
        supports: ['plugins: false', 'mods: false', 'datapacks: true']
    },
    paper: {
        name: 'Paper',
        description: 'High-performance Spigot fork with optimizations and bug fixes',
        category: 'Java Edition',
        icon: 'fas fa-scroll',
        color: '#2196F3',
        downloadUrl: 'https://api.papermc.io/v2/projects/paper/versions/{version}/builds/{build}/downloads/paper-{version}-{build}.jar',
        manifestUrl: 'https://api.papermc.io/v2/projects/paper',
        supports: ['plugins: true', 'mods: false', 'datapacks: true']
    },
    purpur: {
        name: 'Purpur',
        description: 'Paper fork with additional features and configuration options',
        category: 'Java Edition',
        icon: 'fas fa-gem',
        color: '#9C27B0',
        downloadUrl: 'https://api.purpurmc.org/v2/purpur/{version}/latest/download',
        manifestUrl: 'https://api.purpurmc.org/v2/purpur',
        supports: ['plugins: true', 'mods: false', 'datapacks: true']
    },
    spigot: {
        name: 'Spigot',
        description: 'Popular server software with plugin support and performance improvements',
        category: 'Java Edition',
        icon: 'fas fa-fire',
        color: '#FF9800',
        downloadUrl: 'https://hub.spigotmc.org/jenkins/job/BuildTools/lastSuccessfulBuild/artifact/target/BuildTools.jar',
        manifestUrl: null, // Requires BuildTools
        supports: ['plugins: true', 'mods: false', 'datapacks: true']
    },
    bukkit: {
        name: 'CraftBukkit',
        description: 'Original modded server software with plugin API',
        category: 'Java Edition',
        icon: 'fas fa-hammer',
        color: '#795548',
        downloadUrl: 'https://hub.spigotmc.org/jenkins/job/BuildTools/lastSuccessfulBuild/artifact/target/BuildTools.jar',
        manifestUrl: null, // Requires BuildTools
        supports: ['plugins: true', 'mods: false', 'datapacks: true']
    },
    fabric: {
        name: 'Fabric',
        description: 'Lightweight modding platform for modern Minecraft versions',
        category: 'Java Edition',
        icon: 'fas fa-thread',
        color: '#4CAF50',
        downloadUrl: 'https://meta.fabricmc.net/v2/versions/loader/{version}/{loader}/server/jar',
        manifestUrl: 'https://meta.fabricmc.net/v2/versions/game',
        supports: ['plugins: false', 'mods: true', 'datapacks: true']
    },
    forge: {
        name: 'Forge',
        description: 'Popular modding platform with extensive mod ecosystem',
        category: 'Java Edition',
        icon: 'fas fa-anvil',
        color: '#FF5722',
        downloadUrl: 'https://maven.minecraftforge.net/net/minecraftforge/forge/{version}/forge-{version}-installer.jar',
        manifestUrl: 'https://files.minecraftforge.net/net/minecraftforge/forge/promotions_slim.json',
        supports: ['plugins: false', 'mods: true', 'datapacks: true']
    },
    quilt: {
        name: 'Quilt',
        description: 'Modern modding platform forked from Fabric with enhanced features',
        category: 'Java Edition',
        icon: 'fas fa-puzzle-piece',
        color: '#673AB7',
        downloadUrl: 'https://meta.quiltmc.org/v3/versions/loader/{version}/{loader}/server/jar',
        manifestUrl: 'https://meta.quiltmc.org/v3/versions/game',
        supports: ['plugins: false', 'mods: true', 'datapacks: true']
    },
    
    // Proxy Servers
    velocity: {
        name: 'Velocity',
        description: 'Modern, high-performance Minecraft proxy server',
        category: 'Proxy Servers',
        icon: 'fas fa-rocket',
        color: '#00BCD4',
        downloadUrl: 'https://api.papermc.io/v2/projects/velocity/versions/{version}/builds/{build}/downloads/velocity-{version}-{build}.jar',
        manifestUrl: 'https://api.papermc.io/v2/projects/velocity',
        supports: ['plugins: true', 'networks: true', 'modern: true']
    },
    bungeecord: {
        name: 'BungeeCord',
        description: 'Popular proxy server for connecting multiple Minecraft servers',
        category: 'Proxy Servers',
        icon: 'fas fa-network-wired',
        color: '#FF6B35',
        downloadUrl: 'https://ci.md-5.net/job/BungeeCord/lastSuccessfulBuild/artifact/bootstrap/target/BungeeCord.jar',
        manifestUrl: null, // Uses CI builds
        supports: ['plugins: true', 'networks: true', 'legacy: true']
    },
    waterfall: {
        name: 'Waterfall',
        description: 'Paper fork of BungeeCord with performance improvements',
        category: 'Proxy Servers',
        icon: 'fas fa-water',
        color: '#2196F3',
        downloadUrl: 'https://api.papermc.io/v2/projects/waterfall/versions/{version}/builds/{build}/downloads/waterfall-{version}-{build}.jar',
        manifestUrl: 'https://api.papermc.io/v2/projects/waterfall',
        supports: ['plugins: true', 'networks: true', 'optimized: true']
    },
    
    // Bedrock Edition
    bedrock: {
        name: 'Bedrock Dedicated Server',
        description: 'Official Minecraft Bedrock Edition server',
        category: 'Bedrock Edition',
        icon: 'fas fa-mobile-alt',
        color: '#4CAF50',
        downloadUrl: 'https://minecraft.azureedge.net/bin-linux/bedrock-server-{version}.zip',
        manifestUrl: null, // Manual version management
        supports: ['crossplay: true', 'mobile: true', 'console: true']
    },
    nukkit: {
        name: 'Nukkit',
        description: 'Third-party Bedrock Edition server with plugin support',
        category: 'Bedrock Edition',
